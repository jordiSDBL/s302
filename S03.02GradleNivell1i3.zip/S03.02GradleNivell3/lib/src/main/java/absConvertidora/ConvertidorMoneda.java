package absConvertidora;

import operacions.Comanda;

public abstract class ConvertidorMoneda {
	protected Comanda comanda = new Comanda();
	public abstract void mostrar();

}
