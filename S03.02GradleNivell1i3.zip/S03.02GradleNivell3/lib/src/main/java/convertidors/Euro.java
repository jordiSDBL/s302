package convertidors;

import java.text.DecimalFormat;

import absConvertidora.ConvertidorMoneda;
import operacions.Comanda;

public class Euro extends ConvertidorMoneda {
	// per controlar impresio double preu
	DecimalFormat df = new DecimalFormat("#.00");

	// constructor
	public Euro(Comanda comanda) {
		this.comanda = comanda;
	}

	@Override
	public void mostrar() {
		System.out.print("Id comanda: ");
		System.out.println(comanda.idComanda);
		System.out.println("(EN EUROS)");
		for (int i = 0; i < comanda.llistat.size(); i++) {
			System.out.print("--> " + comanda.llistat.get(i).getNom() + ": ");
			System.out.println(df.format(comanda.llistat.get(i).getPreu()) + " �");
		}
	}

}
