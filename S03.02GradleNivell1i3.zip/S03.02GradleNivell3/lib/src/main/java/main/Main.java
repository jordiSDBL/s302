package main;
import absConvertidora.ConvertidorMoneda;
import convertidors.Dolar;
import convertidors.Euro;
import convertidors.Yen;
import operacions.*;

public class Main {
	public static void main(String[] args) {
		// creem uns quants articles
		Article art1 = new Article("sabates", 39.95);
		Article art2 = new Article("cintur�", 19.95);
		Article art3 = new Article("barret", 24.95);
		Article art4 = new Article("pantalons", 59.95);
		// creem una comanda
		Comanda comanda = new Comanda();
		// afegim els articles a la comanda
		comanda.afegirArticle(art1);
		comanda.afegirArticle(art2);
		comanda.afegirArticle(art3);
		comanda.afegirArticle(art4);
		// declarem la classe convertidor
		ConvertidorMoneda convertidor;
		// n'instanciem per a cada tipus i cridem el m�tode sobreescrit mostrar()
		convertidor = new Yen(comanda);
		convertidor.mostrar();
		System.out.println();
		convertidor = new Dolar(comanda);
		convertidor.mostrar();
		System.out.println();
		convertidor = new Euro(comanda);
		convertidor.mostrar();
	}
}