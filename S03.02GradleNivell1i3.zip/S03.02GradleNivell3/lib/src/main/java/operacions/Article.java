package operacions;
/**
 * Classe b�sica per definir articles
 * Nom i preu
 * Getters per poder-hi accedir i que els convertidors en modifiquin el valor
 * @author jsedo
 *
 */
public class Article {
	private String nom;
	private double preu;

	public Article(String nom, double preu) {
		this.nom = nom;
		this.preu = preu;
	}

	public String getNom() {
		return nom;
	}

	public void setNom(String nom) {
		this.nom = nom;
	}

	public double getPreu() {
		return preu;
	}

	public void setPreu(double preu) {
		this.preu = preu;
	}

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("--> ");
		builder.append(nom);
		builder.append(": ");
		builder.append(preu);
		builder.append(".");
		return builder.toString();
	}

}
