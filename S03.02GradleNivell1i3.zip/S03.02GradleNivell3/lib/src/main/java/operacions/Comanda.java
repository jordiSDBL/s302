package operacions;

import java.util.*;
/**
 * Emmagatzeram� article
 * @author jsedo
 *
 */
public class Comanda {
	
	public int idComanda;
	public static int id;
	public List<Article> llistat = new ArrayList<>();

	public Comanda() {
		this.idComanda = ++Comanda.id;
	}

	public void afegirArticle(Article article) {
		llistat.add(article);
	}

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("Comanda id: ");
		builder.append("\n");
		builder.append(llistat);
		return builder.toString();
	}
}
