package tests;

import org.junit.Test;

public class TestProject {

	@Test
	public void verifyNoExceptionThrown() {
		main.Main.main(new String[] {});
	}
}