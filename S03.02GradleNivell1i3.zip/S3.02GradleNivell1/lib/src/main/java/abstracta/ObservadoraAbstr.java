package abstracta;

import observable.AgentBorsa;

public abstract class ObservadoraAbstr {
	protected AgentBorsa agent;
	public abstract void actualitzar();
}
	