package main;

import observable.AgentBorsa;
import observadors.Ibex35;
import observadors.Nyse;

public class Main {
	public static void main(String[] args) {
		// creem un agent de borsa
		AgentBorsa agent = new AgentBorsa();

		// creem observadors lligats a l'agent creat
		new Ibex35(agent);
		new Nyse(agent);

		/**
		 * modifiquem l'atribut de l'observable i desencadenar� la crida dels m�todes
		 * actualitzar dels observadors afegits a la llista.
		 */
		System.out.println("COMUNICACI�:");
		agent.setValor(-10);
		System.out.println();
		System.out.println("COMUNICACI�:");
		agent.setValor(10);
	}
}
