package observable;

import java.util.ArrayList;
import java.util.List;

import abstracta.ObservadoraAbstr;

public class AgentBorsa {
	// llista per emmagatzemar els observadors de la inst�ncia AgentBorsa
	private List<ObservadoraAbstr> observadors = new ArrayList<ObservadoraAbstr>();
	// estat de l'observable que se'n far� seguiment.
	private int valor;
	private String comunicacio = "";

	public int getValor() {
		return valor;
	}

	/**
	 * A banda de ser un setter, llan�a el m�tode que activa el m�tode actualitzar()
	 * de tots els observadors de la inst�ncia AgentBorsa
	 * 
	 * @param valor
	 */
	public void setValor(int valor) {
		this.valor = valor;
		notificarTotsObservadors();
	}

	/**
	 * Afegeix un observador a la llista d'observadors de la inst�ncia de AgentBorsa
	 * 
	 * @param observador
	 */
	public void agregar(ObservadoraAbstr observador) {
		observadors.add(observador);
	}

	/**
	 * Fa constar si la borsa puja o baixa i crida els m�todes actualitzar() dels
	 * observadors associats a la inst�ncia de AgentBorsa
	 */
	public void notificarTotsObservadors() {
		comunicacio = (valor > 0) ? "La borsa HA PUJAT." : "La borsa HA BAIXAT.";
		System.out.println(comunicacio);
		observadors.forEach(x -> x.actualitzar());
	}

}
