package observadors;

import abstracta.ObservadoraAbstr;
import observable.AgentBorsa;

/**
 * Extends de la classe abstracta per poder sobreescriure el m�tode
 * actualitzar() segons convingui
 * 
 * @author jsedo
 *
 */
public class Nyse extends ObservadoraAbstr {

	/**
	 * Es passa per par�metre una inst�ncia de AgentBorsa al constructor per estar
	 * associada a una inst�ncia d'aquesta i a m�s es llan�a el m�tode agregar() que
	 * afegeix aquest observador a la llista d'observadors que t� l'objecte del
	 * tipus AgentBorsa que es cre�
	 * 
	 * @param agent
	 */
	public Nyse(AgentBorsa agent) {
		this.agent = agent;
		this.agent.agregar(this);
	}

	/**
	 * Se sobreescriu el m�tode abstracte actualitzar() per definir quina acci� dur�
	 * a terme aquest observador
	 */
	@Override
	public void actualitzar() {
		System.out.println("NYSE rep la notificaci� de l'agent de borsa.");

	}

}